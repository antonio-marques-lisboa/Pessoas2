import React from 'react';
export default function BackofficeUsers() {
  return <div className="p-6">Backoffice de utilizadores e perfis</div>;
}