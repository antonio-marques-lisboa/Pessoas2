import React from 'react';
export default function BackofficeConfig() {
  return <div className="p-6">Backoffice funcional (nome, ícone, cor)</div>;
}