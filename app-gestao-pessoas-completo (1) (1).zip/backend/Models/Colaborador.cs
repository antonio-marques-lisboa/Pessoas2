namespace DirecaoPessoasAPI.Models
{
    public class Colaborador
    {
        public string Nome { get; set; }
        public int Idade { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public string Direcao { get; set; }
        public string Departamento { get; set; }
        public string Localizacao { get; set; }
    }
}